//
//  DetailViewController.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var dtextView: UITextView!

    var dPlanet: DemoPlanets? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let text = "Name: \( dPlanet?.name ?? "") \n Rotation Period: \(dPlanet?.rotation_period ?? "") \n Orbital Period: \(dPlanet?.orbital_period ?? "") \n Diameter: \(dPlanet?.diameter ?? "") \n Climate: \(dPlanet?.climate ?? "") \n Gravity: \(dPlanet?.gravity ?? "") \n Terrain: \(dPlanet?.terrain ?? "") \n Surface Water: \(dPlanet?.surface_water ?? "") \n Population: \(dPlanet?.population ?? "") \n Created: \(dPlanet?.created ?? "") \n Edited: \(dPlanet?.edited ?? "") \n URL: \(dPlanet?.url ?? "") \n"
        dtextView.text = text
    }
}
