//
//  DemoFilms+CoreDataProperties.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

import Foundation
import CoreData


extension DemoFilms {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DemoFilms> {
        return NSFetchRequest<DemoFilms>(entityName: "DemoFilms")
    }

    @NSManaged public var url: String?
    @NSManaged public var rPlanet: DemoPlanets?

}
