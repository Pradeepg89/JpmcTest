//
//  DemoPlanets+CoreDataProperties.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

import Foundation
import CoreData


extension DemoPlanets {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DemoPlanets> {
        return NSFetchRequest<DemoPlanets>(entityName: "DemoPlanets")
    }

    @NSManaged public var name: String?
    @NSManaged public var rotation_period: String?
    @NSManaged public var orbital_period: String?
    @NSManaged public var diameter: String?
    @NSManaged public var climate: String?
    @NSManaged public var gravity: String?
    @NSManaged public var terrain: String?
    @NSManaged public var surface_water: String?
    @NSManaged public var population: String?
    @NSManaged public var created: String?
    @NSManaged public var edited: String?
    @NSManaged public var url: String?
    @NSManaged public var rResidents: NSSet?
    @NSManaged public var rFilms: NSSet?

}

// MARK: Generated accessors for rResidents
extension DemoPlanets {

    @objc(addRResidentsObject:)
    @NSManaged public func addToRResidents(_ value: DemoResidents)

    @objc(removeRResidentsObject:)
    @NSManaged public func removeFromRResidents(_ value: DemoResidents)

    @objc(addRResidents:)
    @NSManaged public func addToRResidents(_ values: NSSet)

    @objc(removeRResidents:)
    @NSManaged public func removeFromRResidents(_ values: NSSet)

}

// MARK: Generated accessors for rFilms
extension DemoPlanets {

    @objc(addRFilmsObject:)
    @NSManaged public func addToRFilms(_ value: DemoFilms)

    @objc(removeRFilmsObject:)
    @NSManaged public func removeFromRFilms(_ value: DemoFilms)

    @objc(addRFilms:)
    @NSManaged public func addToRFilms(_ values: NSSet)

    @objc(removeRFilms:)
    @NSManaged public func removeFromRFilms(_ values: NSSet)

}
