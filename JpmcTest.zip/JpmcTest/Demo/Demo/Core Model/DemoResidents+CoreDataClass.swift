//
//  DemoResidents+CoreDataClass.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

import Foundation
import CoreData

@objc(DemoResidents)
public class DemoResidents: NSManagedObject {

}
