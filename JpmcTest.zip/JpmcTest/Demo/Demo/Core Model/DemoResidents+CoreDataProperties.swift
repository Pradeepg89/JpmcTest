//
//  DemoResidents+CoreDataProperties.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

import Foundation
import CoreData


extension DemoResidents {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<DemoResidents> {
        return NSFetchRequest<DemoResidents>(entityName: "DemoResidents")
    }

    @NSManaged public var url: String?
    @NSManaged public var rPlanet: DemoPlanets?

}
