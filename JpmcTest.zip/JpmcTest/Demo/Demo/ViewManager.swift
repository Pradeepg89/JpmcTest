//
//  ViewManager.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

//import Foundation
import UIKit
import CoreData

class ViewManager: NSObject {
    
    func fetchDataFromAPI(_ url: String, completionHandler: @escaping (_ result: Array<Any>?, _ error: Error?) -> Void){
        let task = URLSession.shared.dataTask(with: URL(string: url)!) { (data, respose, error) in
            if error != nil {
                print(error as Any)
            } else {
                if let usableData = data {
                    do {
                        let json = try JSONSerialization.jsonObject(with: usableData, options: []) as! Dictionary<String, Any>
                        //po (((json["results"] as Array<Any>)[1]) as Dictionary<String, Any>)["name"]
                        print(json)
                        completionHandler((json["results"] as! Array<Any>), nil)
                        
                    } catch let error as NSError {
                        print(error)
                        completionHandler(nil, error)
                    }
                    
                }
            }
        }
        task.resume()
    }
    
    func storeModel(_ datas: Array<Any>?, completionHandler: @escaping (_ planet: [DemoPlanets]?) -> Void) {
        let fetchRequest: NSFetchRequest<DemoPlanets> = DemoPlanets.fetchRequest()
        do{
            let aPlanets:[DemoPlanets] = (try self.context().fetch(fetchRequest))
            if aPlanets.count == 0 {
                if datas == nil {
                    completionHandler(nil)
                    return
                }
                
                self.insertPlanet(datas!)
                try self.context().save()
                let aPlanets:[DemoPlanets] = (try self.context().fetch(fetchRequest))
                completionHandler(aPlanets)
            } else {
                if datas == nil {
                    completionHandler(aPlanets)
                    return
                }
                
                removeAllPlanets(aPlanets)
                try self.context().save()
                self.insertPlanet(datas!)
                try self.context().save()
                let aPlanets:[DemoPlanets] = (try self.context().fetch(fetchRequest))
                completionHandler(aPlanets)
            }
        } catch {
            completionHandler(nil)
        }
    }
    
    //    Mark:- Private
    fileprivate func context() -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        return appDelegate!.persistentContainer.viewContext
    }
    
    fileprivate func insertPlanet(_ datas: Array<Any>) {
        for object in datas {
            let result = object as! Dictionary<String, Any>
            let entity = NSEntityDescription.entity(forEntityName: "DemoPlanets", in: self.context())
            let planet:DemoPlanets = NSManagedObject(entity: entity!, insertInto: self.context()) as! DemoPlanets
            
            if let name             = result["name"] as? String { planet.name = name }
            if let rotation         = result["rotation_period"] as? String { planet.rotation_period = rotation }
            if let orbital_period   = result["orbital_period"] as? String { planet.orbital_period = orbital_period}
            if let diameter         = result["diameter"] as? String { planet.diameter = diameter }
            if let climate          = result["climate"] as? String { planet.climate = climate }
            if let gravity          = result["gravity"] as? String { planet.gravity = gravity }
            if let terrain          = result["terrain"] as? String { planet.terrain = terrain }
            if let surface_water    = result["surface_water"] as? String { planet.surface_water = surface_water }
            if let population       = result["population"] as? String { planet.population = population }
            if let created          = result["created"] as? String { planet.created = created }
            if let edited           = result["edited"] as? String { planet.edited = edited }
            if let url              = result["url"] as? String { planet.url = url }
            
            if let residents = result["residents"] as? Array<String> {
                for resultResident in residents {
                    if let entity = NSEntityDescription.entity(forEntityName: "DemoResidents", in: self.context()) {
                        let resident:DemoResidents = NSManagedObject(entity: entity, insertInto: self.context()) as! DemoResidents
                        resident.url = resultResident
                        resident.rPlanet = planet
                        planet.addToRResidents(resident)
                    }
                }
            }
            
            if let films = result["films"] as? Array<String> {
                for resultFilms in films {
                    if let entity = NSEntityDescription.entity(forEntityName: "DemoFilms", in: self.context()) {
                        let film:DemoFilms = NSManagedObject(entity: entity, insertInto: self.context()) as! DemoFilms
                        film.url = resultFilms
                        film.rPlanet = planet
                        planet.addToRFilms(film)
                    }
                }
            }
        }
    }
    
    fileprivate func removeAllPlanets(_ aPlanets: [DemoPlanets]) {
        let context = self.context()
        for planet in aPlanets {
            if let arrResident = planet.rResidents?.allObjects {
                for resident in arrResident {
                    if let oResident = resident as? DemoResidents {
                        oResident.rPlanet = nil
                        planet.removeFromRResidents(oResident)
                        context.delete(oResident)
                    }
                }
            }
            
            
            if let arrFilm = planet.rFilms?.allObjects {
                for film in arrFilm {
                    if let oFilm = film as? DemoFilms {
                        oFilm.rPlanet = nil
                        planet.removeFromRFilms(oFilm)
                        context.delete(oFilm)
                    }
                }
            }
            context.delete(planet);
        }
    }
}
