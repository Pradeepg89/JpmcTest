//
//  ViewController.swift
//  Demo
//
//  Created by Pradeep Pandey on 04/01/19.
//  Copyright © 2019 Pradeep Pandey. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var dtableView: UITableView!
    let viewMgr = ViewManager();
    fileprivate var arrPlanets:[DemoPlanets]? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.viewMgr.storeModel(nil, completionHandler: { (planets) in
            if(planets != nil) {
                self.arrPlanets = planets
                self.dtableView.reloadData()
            }
        })
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //Fetch data from API
        self.viewMgr.fetchDataFromAPI("https://swapi.co/api/planets/") { (reponses, error) in
            if(!(error != nil)) {
                if let data =  reponses {
                    //Store data in local
                    self.viewMgr.storeModel(data, completionHandler: { (planets) in
                        if(planets != nil) {
                            self.arrPlanets = planets
                            self.dtableView.reloadData()
                        }
                    })
                }
            }
        }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return false
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let detailViewContl = segue.destination as? DetailViewController else { return }
        detailViewContl.dPlanet = sender as? DemoPlanets
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.arrPlanets == nil ? 0 : 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.arrPlanets == nil { return 0 }
        return (self.arrPlanets?.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:DemoTableViewCell = (tableView.dequeueReusableCell(withIdentifier: "DEMOCELL") as? DemoTableViewCell)!
        let planet = arrPlanets![indexPath.row]
        cell.dLblText.text = planet.name
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let planet = arrPlanets![indexPath.row]
        self.performSegue(withIdentifier: "DetailPushController", sender: planet)
    }
    
}
